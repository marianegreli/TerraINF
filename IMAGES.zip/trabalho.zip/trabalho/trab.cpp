#include<cstdio>
#include<cstdlib>
#include<sstream>
#include<fstream>
#include<iostream>
#include<vector>

#define HASHCONT 20021

const int ALPHABET_SIZE = 59; // A ate Z + ' ' e '.'

// ESTRUTURA DE DADOS PARA O USUARIO (HASH: LISTA DE PONTEIROS DE LID_USNode, USANDO UM NUMERO PRIMO)
typedef struct PID_USJNode
{
    int id_j;
    float nota;
}LID_USJNode;

typedef struct PID_USNode
{
    int id_us;
    struct PID_USNode *prox;
    std::vector<PID_USJNode*> lista;
}LID_USNode;

// ESTRUTURA DE DADOS PARA OS JOGADORES
struct PJNode;

typedef struct PPosL
{
    std::string pos;
    PJNode *proxJ;
    PPosL *prox;
}PosL;

typedef struct PTagsL
{
    std::string tag;
    PJNode *proxJ;
    PTagsL *prox;
}TagsL;

typedef struct PJNode
{
    std::string nome;
    float rating;
    int num_av;
    int id;
    PPosL *pos;
    PTagsL *tags;
    struct PJNode *prox;
}LJNode;

typedef struct TrieNode
{
    struct TrieNode *children[ALPHABET_SIZE];
    bool isEndOfWord;
    LJNode *jogador;
}TrieN;


void PrintaComum(LJNode *jog)
{
    int aux = jog->nome.length();
    PosL *auxP = jog->pos;
    std::cout << jog->id << "\t" << jog->nome;
    if(aux > 39)
    {
        std::cout << "\t";
    }
    else
    {
        if(aux > 31)
        {
            std::cout << "\t\t";
        }
        else
        {
            if(aux > 23)
            {
                std::cout << "\t\t\t";
            }
            else
            {
                if(aux > 15)
                {
                    std::cout << "\t\t\t\t";
                }
                else
                {
                    if(aux > 7)
                    {
                        std::cout << "\t\t\t\t\t";
                    }
                    else
                    {
                        std::cout << "\t\t\t\t\t\t";
                    }
                }
            }
        }
    }
    aux = 0;
    while(auxP != NULL)
    {
        std::cout << auxP->pos << ", ";
        auxP = auxP->prox;
        aux++;
    }
    if(aux == 1)
    {
        std::cout << "\t";
    }
    std::cout << "\t" << jog->rating/jog->num_av << "\t" << jog->num_av << std::endl;
}

void PrintaUsuario(LID_USNode *lUser, std::vector<LJNode*> hashJ)
{
    int idJ, i = 0, aux;
    LID_USJNode *auxUsJ = NULL;
    LJNode *auxJ;

    while(lUser->lista.at(i) != NULL)
    {
        auxUsJ = lUser->lista.at(i);
        idJ = auxUsJ->id_j;
        aux = idJ % HASHCONT;
        auxJ = hashJ.at(aux);
        while(idJ != auxJ->id)
        {
            auxJ = auxJ->prox;
        }
        aux = auxJ->nome.length();
        std::cout << idJ << "\t"<< auxJ->nome;
        if(aux > 39)
        {
            std::cout << "\t";
        }
        else
        {
            if(aux > 31)
            {
                std::cout << "\t\t";
            }
            else
            {
                if(aux > 23)
                {
                    std::cout << "\t\t\t";
                }
                else
                {
                    if(aux > 15)
                    {
                        std::cout << "\t\t\t\t";
                    }
                    else
                    {
                        if(aux > 7)
                        {
                            std::cout << "\t\t\t\t\t";
                        }
                        else
                        {
                            std::cout << "\t\t\t\t\t\t";
                        }
                    }
                }
            }
        }
        std::cout << auxJ->rating/auxJ->num_av << "\t" << auxJ->num_av << "\t" << auxUsJ->nota << std::endl;
        i++;
    }
}

TrieN *getNode(void)
{
    struct TrieNode *pNode =  new TrieNode;

    pNode->isEndOfWord = false;
    pNode->jogador = NULL;

    for (int i = 0; i < ALPHABET_SIZE; i++)
        pNode->children[i] = NULL;

    return pNode;
}

#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<string>
#include<ctime>
#include"parser.hpp"
#include"Tags.cpp"

#define UPPERCASE_A 65
#define UPPERCASE_Z 90

using namespace aria::csv;

std::vector<LJNode*> DestroyHashJ(std::vector<LJNode*> hashJ)
{
    int i = 0;
    LJNode *auxJ = NULL, *auxJ2 = NULL;
    PosL *auxP = NULL, *auxP2 = NULL;

    while(i < HASHCONT)
    {
        if(hashJ.at(i) != NULL)
        {
            auxJ = hashJ.at(i);
            do
            {
                auxP = auxJ->pos;
                while(auxP != NULL)
                {
                    auxP2 = auxP;
                    auxP = auxP->prox;
                    free(auxP2);
                }
                auxJ2 = auxJ;
                auxJ = auxJ->prox;
                free(auxJ2);
            }
            while(auxJ != NULL);
        }
        i++;
    }

    return hashJ;
}

std::vector<LID_USNode*> DestroyHashUs(std::vector<LID_USNode*> hashUs)
{
    int i = 0, j = 0;
    LID_USNode *auxUs = NULL, *auxUs2 = NULL;
    LID_USJNode *auxUsJ = NULL, *auxUsJ2 = NULL;

    while(i < HASHCONT)
    {
        if(hashUs.at(i) != NULL)
        {
            auxUs = hashUs.at(i);
            do
            {
                auxUsJ = auxUs->lista.at(j);
                while(auxUsJ != NULL)
                {
                    auxUsJ2 = auxUsJ;
                    auxUsJ = auxUs->lista.at(++j);
                    free(auxUsJ2);
                }
                auxUs2 = auxUs;
                auxUs = auxUs->prox;
                free(auxUs2);
            }
            while(auxUs != NULL);
            j = 0;
        }
        i++;
    }

    return hashUs;
}

PosL *InsertJPos(int *i, PosL *posAux, std::string container)
{
    int j = 0;
    std::string strAux;

    strAux.resize(3);

    posAux = new PosL;
    while(*i < container.size() && container.at(*i) >= UPPERCASE_A && container.at(*i) < UPPERCASE_Z+1)
    {
        strAux.at(j) = container.at(*i);
        (*i)++;
        j++;
    }
    (*i)+=2;
    strAux.resize(j);
    posAux->pos = strAux;
    posAux->proxJ = NULL;
    posAux->prox = NULL;
    return posAux;
}

LJNode* InsertJog(char c, std::string field, LJNode *jog, TrieN *nodeJN)
{
    int i = 0;
    std::string container = field;
    PosL *posAux1 = NULL, *posAux2 = NULL;

    switch(c)
    {
        case 1:
            jog = new LJNode;
            jog->rating = 0;
            jog->num_av = 0;
            jog->tags = NULL;
            jog->prox = NULL;
            jog->id = std::stoi(field,nullptr);
            break;
        case 2:
            jog->nome = field;
            insertTrieNome(nodeJN, field, jog);
            break;
        case 3:
            container = field;
            /// inserir na ED hashjog
            jog->pos = InsertJPos(&i, jog->pos, container);
            posAux2 = jog->pos;
            while(i-2 < container.size())
            {
                posAux1 = InsertJPos(&i, posAux1, container);
                posAux2->prox = posAux1;
                posAux2 = posAux1;
            }
            break;
    }

    return jog;
}

LJNode* InsertJTags(char c, std::string field, LJNode *jog, TrieN *nodeT, std::vector<LJNode*> *hashJ)
{
    int i = 0, aux;
    LJNode *jAux = NULL;
    TagsL *tagAux1 = NULL, *tagAux2 = NULL;

    switch(c)
    {
       case 2:
            i = std::stoi(field,nullptr);
            aux = i % HASHCONT;
            jAux = hashJ->at(aux);
            while(jAux->id != i)
            {
                jAux = jAux->prox;
            }
            jog = jAux;
            break;

        case 3:
            tagAux1 = jog->tags;
            /// inserir Tag na ED jog
            while(tagAux1 != NULL)
            {
                tagAux2 = tagAux1;
                if(tagAux1->tag == field)
                {
                    i++;
                }
                tagAux1 = tagAux1->prox;
            }
            if(!i)
            {
                tagAux1 = new TagsL;
                tagAux1->prox = NULL;
                tagAux1->proxJ = NULL;
                tagAux1->tag = field;
                if(tagAux2 == NULL)
                {
                    jog->tags = tagAux1;
                }
                else
                {
                    tagAux2->prox = tagAux1;
                }

                /// inserir Tag na ED trie
                insertTrieTags(nodeT, field, jog);
            }
            break;
    }

    return jog;
}

void ManagePlayersFile(std::vector<LJNode*> *hashJ, TrieN *nodeJN)
{
    int auxN;
    char endw = 0;
    LJNode *jog = NULL, *auxJ = NULL;
    std::string aux;
    std::ifstream f("players.csv");
    CsvParser parser(f);

    while(endw != 4) // nao usar os 3 primeiros pedacos de informacao + 1 pula linha
    {
        auto field = parser.next_field();
        endw++;
    }

    endw = 1;
    while(endw)
    {
        auto field = parser.next_field();
        switch (field.type)
        {
            case FieldType::DATA:
                aux = *field.data;
                jog = InsertJog(endw, aux, jog, nodeJN);
                endw++;
                break;

            case FieldType::ROW_END:
                auxN = jog->id % HASHCONT;
                auxJ = hashJ->at(auxN);
                if(auxJ == NULL)
                {
                    hashJ->at(auxN) = jog;
                }
                else
                {
                    while(auxJ->prox != NULL)
                    {
                        auxJ = auxJ->prox;
                    }
                    auxJ->prox = jog;
                }
                endw = 1;
                break;

            case FieldType::CSV_END:
                auxN = jog->id % HASHCONT;
                auxJ = hashJ->at(auxN);
                if(auxJ == NULL)
                {
                    hashJ->at(auxN) = jog;
                }
                else
                {
                    while(auxJ->prox != NULL)
                    {
                        auxJ = auxJ->prox;
                    }
                    auxJ->prox = jog;
                }
                endw = 0;
                break;
        }
    }
}

void ManageTagsFile(std::vector<LJNode*> *hashJ, TrieN *nodeT)
{
    char endw = 0;
    LJNode *jog = NULL;
    std::string aux;
    std::ifstream f("tags.csv");
    CsvParser parser(f);

    while(endw != 4) // nao usar os 3 primeiros pedacos de informacao + 1 pula linha
    {
        auto field = parser.next_field();
        endw++;
    }

    endw = 1;
    while(endw)
    {
        auto field = parser.next_field();
        switch (field.type)
        {
            case FieldType::DATA:
                aux = *field.data;
                if(!aux.empty())
                {
                    jog = InsertJTags(endw, aux, jog, nodeT, hashJ);
                }
                endw++;
                break;

            case FieldType::ROW_END:
                endw = 1;
                break;

            case FieldType::CSV_END:
                endw = 0;
                break;
        }
    }
}

void ManageReviewsFile(std::vector<LID_USNode*> *hashUs, std::vector<LJNode*> *hashJ)
{
    int aux, id;
    char endw = 0;
    LJNode *auxJ = NULL;
    LID_USNode *auxUs = NULL;
    std::string auxS;
    std::vector<float> auxVect(4,0);
    std::ifstream f("rating.csv");
    CsvParser parser(f);

    while(endw != 4) // nao usar os 3 primeiros pedacos de informacao + 1 pula linha
    {
        auto field = parser.next_field();
        endw++;
    }

    endw = 1;
    while(endw)
    {
        auto field = parser.next_field();
        switch (field.type)
        {
            case FieldType::DATA:
                auxS = *field.data;
                auxVect.at(endw) = std::stof(auxS,nullptr);
                endw++;
                break;

            case FieldType::ROW_END:
                aux = (int)auxVect.at(1);
                id = UserHashAd(aux);
                auxUs = hashUs->at(id);
                hashUs->at(id) = InsertUser(auxUs, aux, (int)auxVect.at(2), auxVect.at(3));
                id = (int)auxVect.at(2);
                aux = id % HASHCONT;
                auxJ = hashJ->at(aux);
                while(auxJ->id != id)
                {
                    auxJ = auxJ->prox;
                }
                auxJ->rating += auxVect.at(3);
                (auxJ->num_av)++;
                endw = 1;
                break;

            case FieldType::CSV_END:
                aux = (int)auxVect.at(1);
                id = UserHashAd(aux);
                auxUs = hashUs->at(id);
                hashUs->at(id) = InsertUser(auxUs, aux, (int)auxVect.at(2), auxVect.at(3));
                id = (int)auxVect.at(2);
                aux = id % HASHCONT;
                auxJ = hashJ->at(aux);
                while(auxJ->id != id)
                {
                    auxJ = auxJ->prox;
                }
                auxJ->rating += auxVect.at(3);
                (auxJ->num_av)++;
                endw = 0;
                break;
        }
    }
}

void f(std::vector<LJNode*> hashJ, TrieN *nodeP)
{
    LJNode *auxJ = NULL;
    PosL *auxP = NULL;
    std::string aaaaa{"ST"};
    for(int i = 0 ; i < HASHCONT ; i++)
    {
        auxJ = hashJ.at(i);
        while(auxJ != NULL)
        {
            auxP = auxJ->pos;
            while(auxP != NULL)
            {
                insertTriePos(nodeP, auxP->pos, auxJ);
                if(!auxP->pos.compare(aaaaa))
                {
                    //printf("\n");
                    //PrintaComum(auxJ);
                    //searchTriePos(nodeP, aaaaa, 1000);
                    //printf("\n\n\n\n\n\n");
                }
                auxP = auxP->prox;
            }
            auxJ = auxJ->prox;
        }
    }
}

void Search(TrieN *nodeJN, TrieN *nodeP, TrieN *nodeT, std::vector<LJNode*> hashJ, std::vector<LID_USNode*> hashUs)
{
    int id, i, j;
    std::string line, aux;

    while(line.compare(0,4,"exit"))
    {
        printf("$ ");
        std::getline(cin, line);
        if(line.length() < 7)
        {
             line.resize(7);
        }
        if(!line.compare(0,7,"player ")) // OOK
        {
            aux = line.substr(7);
            searchTrieNomes(nodeJN, aux);
        }
        else
        {
            if(!line.compare(0,5,"user ")) // OOK
            {
                aux = line.substr(5);
                id = std::stoi(aux,nullptr);
                SearchUser(hashUs, hashJ, id);
            }
            else
            {
                if(!line.compare(0,3,"top")) // OOK
                {
                    i = 1;
                    do
                    {
                        aux = line.substr(3,i);
                        i++;
                    }
                    while(line.at(i+2) != ' ');
                    id = std::stoi(aux,nullptr);
                    i+=4;
                    aux = line.substr(i);
                    aux.resize(aux.length() - 1);
                    searchTriePos(nodeP, aux, id);
                }
                else
                {
                    if(!line.compare(0,6,"tags '"))
                    {
                        searchTags(line, nodeT);
                    }
                    else
                    {
                        if(!line.compare("exit"))
                        {
                            printf("Erro: comando entrado eh invalido.\n\n\n");
                        }
                    }
                }
            }
        }
    }
}

int main()
{
    TrieN *nodeJN = getNode(), *nodeP = getNode(), *nodeT = getNode();
    static std::vector<LJNode*> hashJ(HASHCONT,NULL);
    static std::vector<LID_USNode*> hashUs(HASHCONT,NULL);
    clock_t c;

    c = clock();
    ManagePlayersFile(&hashJ, nodeJN);
    ManageTagsFile(&hashJ, nodeT);
    ManageReviewsFile(&hashUs, &hashJ);
    f(hashJ, nodeP);
    printf("%d\n\n", (clock()-c)/CLK_TCK);

    Search(nodeJN, nodeP, nodeT, hashJ, hashUs);

    hashJ = DestroyHashJ(hashJ);
    nodeJN = DestroyTrie(nodeJN);
    nodeP = DestroyTrie(nodeP);
    nodeT = DestroyTrie(nodeT);

    return 0;
}

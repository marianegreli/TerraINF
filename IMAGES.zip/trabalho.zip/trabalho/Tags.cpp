#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <iostream>
#include <string>
#include"TrieNomes.cpp"

using namespace std;

TagsL* AchaTags(TagsL *l, string key)
{
    TagsL* tagsAux = l;
    while(key.compare(tagsAux->tag)) // percorre a lista de posicoes ate achar a correta
    {
        tagsAux = tagsAux->prox;
    }

    return tagsAux;
}

void insertTags(TrieN *pCrawl, string key, LJNode *jog)
{
    LJNode *pjAux = pCrawl->jogador;
    TagsL* tagsAux = AchaTags(pjAux->tags, key);

    while(tagsAux->proxJ != NULL) // pos e jogadores inserir
    {
        pjAux = tagsAux->proxJ;
        tagsAux = AchaTags(pjAux->tags, key);
    }

    tagsAux = AchaTags(pjAux->tags, key);
    tagsAux->proxJ = jog;
}

void insertTrieTags(TrieN *root, string key, LJNode *jog)
{
    TrieN *pCrawl = root;

    for (int i = 0; i < key.length(); i++)
    {
        int index = toupper(key[i]) - ' ';

        if (!pCrawl->children[index])
        {
            pCrawl->children[index] = getNode();
        }

        pCrawl = pCrawl->children[index];
    }

    // mark last node as leaf
    pCrawl->isEndOfWord = true;
    if(pCrawl->jogador == NULL)
    {
        pCrawl->jogador = jog;
    }
    else
    {
        insertTags(pCrawl, key, jog);
    }
}

TagsL* AchaTagsSearch(TagsL *l, string key)
{
    TagsL* tagsAux = l;
    while(key.compare(tagsAux->tag)) // percorre a lista de posicoes ate achar a correta
    {
        tagsAux = tagsAux->prox;

        if(tagsAux == NULL)
        {
            return NULL;
        }
    }

    return tagsAux;
}

void ProcuraJogadorTags(LJNode *Jog, TagsL *lTags)
{
    string key = lTags->tag, keyAux;
    LJNode *auxJ = Jog;
    TagsL *tagsAux1 = lTags->prox, *tagsAux2 = NULL;
    while(auxJ != NULL)
    {
        while(tagsAux1 != NULL && auxJ != NULL)
        {
            keyAux = tagsAux1->tag;
            if(AchaTagsSearch(auxJ->tags, keyAux) == NULL)
            {
                tagsAux2 = AchaTags(auxJ->tags, key);
                auxJ = tagsAux2->proxJ;
                tagsAux1 = lTags;
            }
            else
            {
                tagsAux1 = tagsAux1->prox;
            }
        }
        if(auxJ != NULL)
        {
            PrintaComum(auxJ);
            tagsAux2 = AchaTags(auxJ->tags, key);
            auxJ = tagsAux2->proxJ;
            tagsAux1 = lTags;
        }
    }
    //return auxJ;
}

void searchTrieTags(TrieN *root, TagsL *lTags)
{
    string key = lTags->tag, keyAux;
    TrieN *pCrawl = root;
    LJNode *pjAux = NULL;

    for (int i = 0; i < key.length(); i++)
    {
        int index = toupper(key[i]) - ' ';

        if (!pCrawl->children[index])
        {
            printf("Erro: argumento entrado invalido\n\n\n");
        }

        pCrawl = pCrawl->children[index];
    }
    pjAux = pCrawl->jogador;
    ProcuraJogadorTags(pjAux, lTags);
}

void searchTags(std::string line, TrieN *nodeT)
{
    int i = 5, j = 0, id = 0;
    TagsL *lTags = NULL, *auxT1 = NULL, *auxT2 = NULL;
    std::string aux;

    while(i < line.length())
    {
        switch(line.at(i))
        {
            case '\'':
                if(id)
                {
                    id = 0;
                    auxT1 = new TagsL;
                    auxT1->tag = aux;
                    auxT1->prox = NULL;
                    auxT1->proxJ = NULL;
                    auxT2 = lTags;
                    if(auxT2 == NULL)
                    {
                        lTags = auxT1;
                    }
                    else
                    {
                        while(auxT2->prox != NULL)
                        {
                            auxT2 = auxT2->prox;
                        }
                        auxT2->prox = auxT1;
                    }
                }
                else
                {
                    id = 1;
                }
                j = 0;
                break;
            default:
                if(id)
                {
                    aux.resize(j+1);
                    aux.at(j) = line.at(i);
                    j++;
                }
                break;
        }
        i++;
    }
    auxT1 = lTags;
    while(auxT1 != NULL)
    {
        auxT1 = auxT1->prox;
    }
    searchTrieTags(nodeT, lTags);
    while(lTags != NULL)
    {
        auxT1 = lTags;
        lTags = lTags->prox;
        delete auxT1;
    }
}

#include <cstdio> // 20021
#include <cstdlib>
#include <cctype>
#include <iostream>
#include <string>
#include <vector>
#include"triePos.cpp"

#define MAX_JOG 20
#define MAX_JOGEX 21

void insertUJog(LID_USNode *User, int id, float nota)
{
    int i = 0;
    LID_USJNode *ljAux1 = NULL, *ljAux2 = NULL, *jog = NULL;

    do
    {
        ljAux1 = User->lista.at(i);
        i++;
        ljAux2 = User->lista.at(i);
    }
    while(ljAux1->nota >= nota && ljAux2 != NULL);

    if(ljAux1->nota >= nota) // no final
    {
        if(i < MAX_JOG)
        {
            jog = new LID_USJNode;
            jog->id_j = id;
            jog->nota = nota;
            User->lista.at(i) = jog;
        }
    }
    else // no "meio" (ARRUMAR)
    {
        jog = new LID_USJNode;
        jog->id_j = id;
        jog->nota = nota;
        User->lista.at(i-1) = jog;
        while(ljAux2 != NULL)
        {
            User->lista.at(i) = ljAux1;
            ljAux1 = ljAux2;
            i++;
            ljAux2 = User->lista.at(i);
        }

        if(i < MAX_JOG)
        {
            User->lista.at(i) = ljAux1;
        }

    }
    //User->lista.at(MAX_JOG) = NULL;
}

LID_USNode *InsertUser(LID_USNode *lUsers, int idUs, int id, float nota)
{
    LID_USNode *lAux = lUsers;
    LID_USJNode *jog = NULL;

    if(lAux == NULL)
    {
        jog = new LID_USJNode;
        jog->id_j = id;
        jog->nota = nota;
        lAux = new LID_USNode;
        lAux->lista.assign(MAX_JOGEX,NULL);
        lAux->lista.at(0) = jog;
        lAux->id_us = idUs;
        lAux->prox = NULL;
        lUsers = lAux;
    }
    else
    {
        while(lAux->id_us != idUs && lAux->prox != NULL)//nodo nullo
        {
            lAux = lAux->prox;
        }

        if(lAux->id_us == idUs)
        {
            insertUJog(lAux, id, nota);
        }
        else
        {
            jog = new LID_USJNode;
            jog->id_j = id;
            jog->nota = nota;
            lAux->prox = new LID_USNode;
            lAux->prox->lista.assign(MAX_JOGEX,NULL);
            lAux->prox->lista.at(0) = jog;
            lAux->prox->id_us = idUs;
            lAux->prox->prox = NULL;
        }
    }

    return lUsers;
}

int UserHashAd(int id)
{
    return id % HASHCONT;
}

void SearchUser(std::vector<LID_USNode*> lUsers, std::vector<LJNode*> hashJ, int id)
{
    int index = id % HASHCONT;
    LID_USNode* lAux = lUsers.at(index);

    while(lAux->id_us != id && lAux->prox != NULL)
    {
        lAux = lAux->prox;
    }

    if(lAux->id_us == id)
    {
        PrintaUsuario(lAux, hashJ);
    }
    else
    {
        printf("Erro: argumento entrado invalido\n\n\n");
    }
}

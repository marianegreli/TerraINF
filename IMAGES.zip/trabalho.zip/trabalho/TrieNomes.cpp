#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <iostream>
#include <string>
#include"tUsers.cpp"

using namespace std;

void insertTrieNome(TrieN *root, string key, LJNode *jog)
{
    TrieN *pCrawl = root;
    for (int i = 0; i < key.length(); i++)
    {
        int index = toupper(key[i]) - ' ';

        if (!pCrawl->children[index])
        {
            pCrawl->children[index] = getNode();
        }
        pCrawl = pCrawl->children[index];
    }

    // mark last node as leaf
    pCrawl->isEndOfWord = true;
    pCrawl->jogador = jog;
}

void VarreduraPorJogadores(TrieN *pCrawl)
{
    TrieN *pAux = pCrawl;

    if(pAux != NULL)
    {
        if(pCrawl->jogador != NULL)
        {
            PrintaComum(pCrawl->jogador);
        }
        for(int i = 0 ; i < ALPHABET_SIZE ; i++)
        {
            pCrawl = pCrawl->children[i];
            VarreduraPorJogadores(pCrawl);
            pCrawl = pAux;
        }
    }
}

// Returns true if key presents in trie, else
// false
void searchTrieNomes(TrieN *root, string key)
{
    int index;
    TrieN *pCrawl = root;

    for (int i = 0; i < key.length(); i++)
    {
        index = toupper(key[i]) - ' ';

        if (!pCrawl->children[index])
        {
            printf("Erro: argumento entrado invalido\n\n\n");
        }

        pCrawl = pCrawl->children[index];
    }
    VarreduraPorJogadores(pCrawl);
}

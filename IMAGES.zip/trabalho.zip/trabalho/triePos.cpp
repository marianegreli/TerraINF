#include <cstdio> // 20021
#include <cstdlib>
#include <cctype>
#include <iostream>
#include <string>
#include"trab.cpp"

using namespace std;

TrieN *DestroyTrie(TrieN *trieP)
{
    if(trieP != NULL)
    {
        for(int i = 0 ; i < ALPHABET_SIZE ; i++)
        {
            DestroyTrie(trieP->children[i]);
        }
        free(trieP);
    }
    return trieP;
}

PosL* AchaPosicao(PosL *l, string key)
{
    PosL* posAux = l;
    while(key.compare(posAux->pos)) // percorre a lista de posicoes ate achar a correta
    {
        posAux = posAux->prox;
    }

    return posAux;
}

LJNode *insertPos(TrieN *pCrawl, string key, LJNode *jog)
{
    LJNode *pjAux1 = pCrawl->jogador, *pjAux2 = NULL;
    PosL *posAux = AchaPosicao(pjAux1->pos, key);
    float notajog = jog->rating/jog->num_av;
    float auxF = pjAux1->rating/pjAux1->num_av;

    // search for the appropriate space to place the node

    while(auxF >= notajog && posAux->proxJ != NULL) // pos e jogadores inserir
    {
        pjAux2 = pjAux1;
        pjAux1 = posAux->proxJ;
        auxF = pjAux1->rating/pjAux1->num_av;
        posAux = AchaPosicao(pjAux1->pos, key);
    }

    if(pjAux2 == NULL)
    {
        if(auxF >= notajog) // segunda posicao (somente 2 nodos)
        {
            posAux->proxJ = jog;
        }
        else // primeira posicao (PROBLEMAS AQUI)
        {
            pCrawl->jogador = jog;
            posAux = AchaPosicao(jog->pos, key);
            posAux->proxJ = pjAux1;
            return jog;
        }
    }
    else
    {
        if(auxF < notajog) // no meio
        {
            posAux = AchaPosicao(jog->pos, key);
            posAux->proxJ = pjAux1;
            posAux = AchaPosicao(pjAux2->pos, key);
            posAux->proxJ = jog;
        }
        else // ultima posicao
        {
            posAux->proxJ = jog;
        }
    }
    return pCrawl->jogador;
}

void insertTriePos(TrieN *pCrawl, string key, LJNode *jog)
{
    if(jog->num_av >= 1000)
    {
        for (int i = 0; i < key.length(); i++)
        {
            int index = toupper(key[i]) - ' ';
            if(pCrawl->children[index] == NULL)
            {
                pCrawl->children[index] = getNode();
            }

            pCrawl = pCrawl->children[index];
        }
        // mark last node as leaf
        pCrawl->isEndOfWord = true;
        if(pCrawl->jogador == NULL)
        {
            pCrawl->jogador = jog;
        }
        else
        {
            pCrawl->jogador = insertPos(pCrawl, key, jog);
        }
    }
}

void searchTriePos(TrieN *root, string key, int num)
{
    TrieN *pCrawl = root;
    LJNode *pjAux = NULL;
    PosL *posAux = NULL;

    for (int i = 0; i < key.length(); i++)
    {
        int index = toupper(key[i]) - ' ';
        if (!pCrawl->children[index])
        {
            printf("Erro: argumento entrado invalido\n\n\n");
        }

        pCrawl = pCrawl->children[index];
    }

    pjAux = pCrawl->jogador;
    while(num && pjAux)
    {
        if(pjAux->num_av >= 1000)
        {
            PrintaComum(pjAux);
            num--;
        }
        posAux = AchaPosicao(pjAux->pos, key);
        pjAux = posAux->proxJ;
    }
}
